bash run1.sh && batcat text1.txt
bash run2.sh && batcat text2.txt
bash run3_1.sh && batcat text3_1.txt
bash run3_2.sh && batcat text3_2.txt
#bash run4.sh && batcat text4.sh
bash run5.sh && batcat text5.txt
bash run6.sh && batcat text6.txt
#bash run7.sh && batcat text7.sh

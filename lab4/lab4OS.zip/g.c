#include <stdio.h>

int main(){
    fork();
    printf("Hello world\n");
}
